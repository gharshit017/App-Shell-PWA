import React from 'react'

const FlickerMenu = () => {
  return (
    <div>FlickerMenu</div>
  )
}

export default FlickerMenu