import React from 'react'

const Script = () => {
  return (
    <div>Script</div>
  )
}

export default Script